package app;
import javax.swing.*;



public class Linkeding 
{
    public static void main(String args[]) 
    {
        /* JFrame */
        JFrame a = new JFrame("Linkeding");
        a.setSize(1300, 1000);
        a.setLayout(null);
        a.setVisible(true);

        /* Imagen*/
        JLabel imgenJLabel = new JLabel("Inserte su imagen aqui");
/*------- */        imgenJLabel.setIcon(new ImageIcon ("C:/Users/elrey/Desktop/sosth/enero/Components_Parfums/lib/imagen_perfil.png"));
        imgenJLabel.setBounds(1150, 50, 250, 250);

        /* Labels nombre y apellidos */
        JLabel b1 = new JLabel("Bienvenido. Es hora de crear tu perfil para empezar");
        b1.setBounds(50, 50, 950, 50);
        JLabel b2 = new JLabel("nombre");
        b2.setBounds(50, 150, 200, 50);
        JLabel b3 = new JLabel("Apellidos");
        b3.setBounds(50, 250, 200, 50);
        JLabel b4 = new JLabel("Pais");
        b4.setBounds(50, 350, 200, 50);

        /*Text Files nombre y apellidos */
        JTextField c2 = new JTextField("");
        c2.setBounds(300, 150, 800, 50);

        JTextField c3 = new JTextField("");
        c3.setBounds(300, 250, 800, 50);



        /* Combo Box */
        JComboBox<String> pais = new JComboBox<String>();
        pais.addItem("España");
        pais.addItem("Italia");
        pais.addItem("Francia");
        pais.addItem("Reino Unido");
        pais.addItem("Portugal");
        pais.setBounds(50,350,800,50);

        /*Estudios */
        DefaultListModel<String> x = new DefaultListModel<>();
        x.addElement("Estudio");
        x.addElement("Trabajo");

        JList<String> lista = new JList<>(x);
        lista.setBounds(50, 450, 200, 100);

        /* Boton de click al finalizar */
        JButton boton = new JButton("click me to create your profile");
        boton.setBounds(500, 800, 500, 50);

        /* Añadir los objetos, listas y demas al cuadro */
        a.add(imgenJLabel);
        a.add(b1);
        a.add(b2);
        a.add(b3);
        a.add(b4);
        a.add(c2);
        a.add(c3);
        a.add(lista);
        a.add(boton);
    }
}           

