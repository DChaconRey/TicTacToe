/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author advance
 * github profile : https://github.com/Saurabh1999
 */
public class type {
    
    public enum pieces{
        X,O,emp;
    }
}
